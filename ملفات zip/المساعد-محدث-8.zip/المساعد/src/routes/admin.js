import os from 'node:os';
import {DatabaseSync as DBX} from 'node:sqlite';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import {route, PORT, db, all, normAr, seedSkills, seedSections, err, tx, hash, check, notify, bal, award, audit, startSession, userOf, need, adm, str, num, R, ADMIN, get, run, SET, restricted, hitOr429, DB_PATH, RESTORE_PENDING, can, helperOf, ensureCommission} from '../core.js';
route('GET','/admin/reports',c=>{can(c,'support');const Q={user:'SELECT name t FROM users WHERE id=?'};
return all("SELECT rp.*,u.name reporter FROM reports rp JOIN users u ON u.id=rp.reporter_id ORDER BY (rp.status='open') DESC,rp.id DESC LIMIT 100").map(r=>({...r,info:get(Q[r.type],r.target_id)?.t}))});
route('POST','/admin/reports/(\\d+)/resolve',c=>{const a=can(c,'support'),r=get('SELECT * FROM reports WHERE id=?',c.p[0]);if(!r)throw err(404,'غير موجود');const note=str(c.b.note,3,300,'الملاحظة');if(c.b.hide&&r.type==='user'&&a.role!=='admin')throw err(403,'إيقاف الحسابات للمدير فقط');
if(c.b.hide){if(r.type==='rating')run('UPDATE ratings SET hidden=1 WHERE id=?',r.target_id);if(r.type==='user'&&r.target_id!==a.id){run('UPDATE users SET active=0 WHERE id=?',r.target_id);run('DELETE FROM sessions WHERE user_id=?',r.target_id)}}
run("UPDATE reports SET status='resolved',note=? WHERE id=?",note,r.id);audit(a.id,'report',`${r.id}:${r.type}:${c.b.hide?'hide':'keep'}:${note}`);return{ok:1}});
route('GET','/admin/stats',c=>{adm(c);const n=s=>get(s).n;return{users:n('SELECT COUNT(*) n FROM users'),points_issued:n('SELECT COALESCE(SUM(delta),0) n FROM points_ledger WHERE delta>0'),rules:all('SELECT * FROM reward_rules'),users_list:all('SELECT id,name,email,role,active,phone,flagged,suspended_until,(flagged=1 OR suspended_until>datetime(\'now\')) restricted,(SELECT COUNT(*) FROM pledges WHERE user_id=users.id) pledged,(SELECT COUNT(*) FROM agreement_cancellations c WHERE c.by_id=users.id AND c.created_at>datetime(\'now\',\'-30 days\')) cancels FROM users ORDER BY id DESC LIMIT 100')}});
route('POST','/admin/rules',c=>{const a=adm(c),p=+c.b.points;if(!Number.isInteger(p)||p<0||!get('SELECT 1 x FROM reward_rules WHERE key=?',c.b.key))throw err(400,'قيمة غير صالحة');
run('UPDATE reward_rules SET points=? WHERE key=?',p,c.b.key);audit(a.id,'rule',`${c.b.key}=${p}`);return{ok:1}});
route('POST','/admin/users/(\\d+)/active',c=>{const a=adm(c),why=str(c.b.reason,3,300,'السبب');if(+c.p[0]===a.id)throw err(400,'لا يمكنك تعطيل حسابك');
run('UPDATE users SET active=? WHERE id=?',c.b.active?1:0,+c.p[0]);if(!c.b.active)run('DELETE FROM sessions WHERE user_id=?',+c.p[0]);audit(a.id,'user_active',`${c.p[0]}:${c.b.active}:${why}`);return{ok:1}});
route('POST','/admin/settings',c=>{const a=adm(c),b=c.b,ib=String(b.iban||'').replace(/\s/g,'').toUpperCase(),cp=+b.commission_percent||0,gd=b.commission_grace_days===''||b.commission_grace_days==null?3:Math.max(0,Math.floor(+b.commission_grace_days||0));if(!/^SA\d{22}$/.test(ib))throw err(400,'رقم الآيبان غير صالح (SA متبوعة بـ 22 رقمًا)');if(cp<0||cp>100)throw err(400,'نسبة العمولة من 0 إلى 100');
const v={bank_name:str(b.bank_name,2,80,'اسم البنك'),account_name:str(b.account_name,2,120,'اسم الحساب'),iban:ib,commission_percent:String(cp),commission_grace_days:String(gd)};for(const k of ['org_name','org_cr','dispute_clause','penalty_rules','support_email','support_phone','support_address'])if(String(b[k]||'').trim())v[k]=str(b[k],2,3000,k);
for(const k of ['terms_text','privacy_text'])if(String(b[k]||'').trim())v[k]=str(b[k],2,20000,k);for(const k of ['cancel_warn_at','cancel_suspend_at','cancel_review_at','cancel_suspend_days']){if(String(b[k]??'')!==''){const n=Math.floor(+b[k]);if(!(n>=1&&n<=3650))throw err(400,'قيمة غير صالحة لإعدادات الإلغاء');v[k]=String(n)}}
for(const k in v)run('INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',k,v[k]);audit(a.id,'settings',`iban=${ib};commission=${cp}`);return{ok:1}});
route('GET','/admin/users/(\\d+)/pledge',c=>{adm(c);const r=get('SELECT text,ip,accepted_at FROM pledges WHERE user_id=? ORDER BY id DESC',c.p[0]);if(!r)throw err(404,'لم يوقّع هذا المستخدم التعهد بعد');return r});
route('POST','/admin/users/(\\d+)/lift',c=>{const a=adm(c),why=str(c.b.reason,3,300,'السبب');run('UPDATE users SET flagged=0,suspended_until=NULL WHERE id=?',+c.p[0]);audit(a.id,'lift',`${c.p[0]}:${why}`);notify(+c.p[0],'تم رفع القيود عن حسابك','#/profile');return{ok:1}});
route('GET','/admin/finance',c=>{adm(c);
const sum=s=>get(s).s;
const income=sum("SELECT COALESCE(SUM(amount),0) s FROM agreement_commissions WHERE status='paid'"),due=sum("SELECT COALESCE(SUM(amount),0) s FROM agreement_commissions WHERE status='due'"),expenses=sum("SELECT COALESCE(SUM(amount),0) s FROM expenses"),transfers=0;
const ledger=[...all("SELECT 'وارد' type,'عمولة مؤكدة من اتفاق' title,amount,COALESCE(paid_at,created_at) at FROM agreement_commissions WHERE status='paid' ORDER BY id DESC LIMIT 60"),...all("SELECT 'صادر' type,title,amount,created_at at FROM expenses ORDER BY id DESC LIMIT 60")].sort((a,b)=>String(b.at).localeCompare(String(a.at))).slice(0,80);
return{income,due,expenses,profit:income-expenses,transfers,ledger}});
route('POST','/admin/expenses',c=>{const a=adm(c),title=str(c.b.title,3,120,'البند'),amt=Number(c.b.amount),cat=str(c.b.category||'',0,60,'التصنيف');if(!(amt>0)||amt>1e7)throw err(400,'المبلغ غير صالح');run('INSERT INTO expenses(title,amount,category,by_id) VALUES(?,?,?,?)',title,amt,cat||null,a.id);audit(a.id,'expense',`${title}:${amt}`);return{ok:1}});
route('GET','/admin/users/(\\d+)/activity',c=>{adm(c);const id=+c.p[0],u=get('SELECT id,name,email,city,role,active,flagged FROM users WHERE id=?',id);if(!u)throw err(404,'المستخدم غير موجود');
return{user:u,agreements:get('SELECT COUNT(*) n FROM agreements WHERE a_id=? OR b_id=?',id,id).n,cancels:get('SELECT COUNT(*) n FROM agreement_cancellations WHERE by_id=?',id).n,cancels30:get("SELECT COUNT(*) n FROM agreement_cancellations WHERE by_id=? AND created_at>datetime('now','-30 days')",id).n,reports_against:get("SELECT COUNT(*) n FROM reports WHERE type='user' AND target_id=?",id).n,reports_by:get('SELECT COUNT(*) n FROM reports WHERE reporter_id=?',id).n,rating:get('SELECT ROUND(AVG(stars),1) a,COUNT(*) n FROM ratings WHERE ratee_id=? AND hidden=0',id),pledged:!!get('SELECT 1 x FROM pledges WHERE user_id=?',id)}});

route('GET','/admin/agreement-commissions',c=>{can(c,'finance');return all("SELECT ac.id,ac.amount,ac.status,ac.created_at,u.name helper,a.description FROM agreement_commissions ac JOIN users u ON u.id=ac.helper_id JOIN agreements a ON a.id=ac.agreement_id WHERE ac.status='due' ORDER BY ac.id DESC LIMIT 200")});
route('GET','/admin/failed-searches',c=>{adm(c);return all("SELECT f.text,f.reason,f.city,f.category_id,c.name category,COUNT(*) n,MAX(f.at) last FROM failed_searches f LEFT JOIN skill_categories c ON c.id=f.category_id GROUP BY f.text,f.reason,f.city,f.category_id ORDER BY n DESC,last DESC LIMIT 100")});
route('POST','/admin/sections/(\\d+)/keywords',c=>{const a=adm(c),cat=get('SELECT id,name FROM skill_categories WHERE id=?',+c.p[0]);if(!cat)throw err(404,'القسم غير موجود');const kws=String(c.b.keywords||'').split(/[,،]/).map(normAr).filter(x=>x.length>=2&&x.length<=60).slice(0,15);if(!kws.length)throw err(400,'أدخل كلمة واحدة على الأقل');for(const k of kws)run('INSERT OR IGNORE INTO section_keywords(category_id,word) VALUES(?,?)',cat.id,k);audit(a.id,'section_keywords',`${cat.name}:${kws.join('،')}`);return{ok:1,added:kws}});
route('GET','/admin/audit',c=>{adm(c);return all("SELECT a.id,a.action,a.detail,a.at,u.name admin FROM audit_log a LEFT JOIN users u ON u.id=a.admin_id ORDER BY a.id DESC LIMIT 200")});
route('POST','/admin/users/(\\d+)/role',c=>{const a=adm(c),id=+c.p[0],role=c.b.role;if(!['user','admin'].includes(role))throw err(400,'دور غير صالح');if(id===a.id)throw err(400,'لا يمكنك تغيير دورك بنفسك');if(!get('SELECT 1 x FROM users WHERE id=?',id))throw err(404,'المستخدم غير موجود');
const why=str(c.b.reason,3,300,'السبب');run('UPDATE users SET role=? WHERE id=?',role,id);audit(a.id,'role',`${id}:${role}:${why}`);return{ok:1}});
route('POST','/admin/users/(\\d+)/password',c=>{const a=adm(c),id=+c.p[0];if(!get('SELECT 1 x FROM users WHERE id=?',id))throw err(404,'المستخدم غير موجود');const pw=str(c.b.password,8,100,'كلمة المرور'),why=str(c.b.reason,3,300,'السبب');
run('UPDATE users SET pass=? WHERE id=?',hash(pw),id);run('DELETE FROM sessions WHERE user_id=?',id);audit(a.id,'password_reset',`${id}:${why}`);notify(id,'تم تغيير كلمة مرورك بواسطة الإدارة، سجّل دخولك بالكلمة الجديدة','#/login');return{ok:1}});
route('POST','/admin/broadcast',c=>tx(()=>{const a=adm(c),text=str(c.b.text,5,500,'النص'),link=String(c.b.link||'#/').slice(0,200);const us=all('SELECT id FROM users WHERE active=1');us.forEach(x=>notify(x.id,text,link));audit(a.id,'broadcast',`${us.length}:${text.slice(0,80)}`);return{sent:us.length}}));
route('GET','/admin/backup',c=>{const a=adm(c),f=path.join(os.tmpdir(),`musaed-backup-${Date.now()}.db`);db.exec(`VACUUM INTO '${f.replace(/'/g,"''")}'`);const raw=fs.readFileSync(f);fs.unlinkSync(f);audit(a.id,'backup','manual');return{raw,mime:'application/octet-stream'}});
route('GET','/admin/skills',c=>{adm(c);return all("SELECT s.id,s.name,s.status,c.name cat,u.name suggested_by,(SELECT GROUP_CONCAT(word,'، ') FROM skill_keywords k WHERE k.skill_id=s.id) keywords FROM skills s JOIN skill_categories c ON c.id=s.category_id LEFT JOIN users u ON u.id=s.suggested_by ORDER BY (s.status='pending') DESC,s.id DESC LIMIT 200")});
route('POST','/admin/skills/(\\d+)/review',c=>{const a=adm(c),s=get('SELECT * FROM skills WHERE id=?',+c.p[0]);if(!s)throw err(404,'غير موجود');if(s.status!=='pending')throw err(400,'هذه المهارة ليست بانتظار الاعتماد');const d=c.b.decision;
if(d==='approve'){run("UPDATE skills SET status='approved' WHERE id=?",s.id);run('INSERT OR IGNORE INTO section_keywords(category_id,word) SELECT s.category_id,k.word FROM skill_keywords k JOIN skills s ON s.id=k.skill_id WHERE k.skill_id=?',s.id);audit(a.id,'skill_approve',s.name);if(s.suggested_by)notify(s.suggested_by,`تم اعتماد مهارتك «${s.name}»`,'#/profile');return{ok:1}}
if(d==='reject'){const why=str(c.b.reason,3,300,'السبب');run('DELETE FROM user_skills WHERE skill_id=?',s.id);run('DELETE FROM skill_keywords WHERE skill_id=?',s.id);run('DELETE FROM skills WHERE id=?',s.id);audit(a.id,'skill_reject',`${s.name}:${why}`);if(s.suggested_by)notify(s.suggested_by,`لم تُعتمد مهارة «${s.name}»: ${why}`,'#/profile');return{ok:1}}
throw err(400,'قرار غير صالح')});
route('POST','/admin/skills/(\\d+)/keywords',c=>{const a=adm(c),s=get('SELECT id,name FROM skills WHERE id=?',+c.p[0]);if(!s)throw err(404,'غير موجود');const kws=String(c.b.keywords||'').split(/[,،]/).map(normAr).filter(x=>x.length>=2).slice(0,15);if(!kws.length)throw err(400,'أدخل كلمة واحدة على الأقل');for(const k of kws){run('INSERT OR IGNORE INTO skill_keywords(skill_id,word) VALUES(?,?)',s.id,k);run('INSERT OR IGNORE INTO section_keywords(category_id,word) SELECT category_id,? FROM skills WHERE id=?',k,s.id)}audit(a.id,'skill_keywords',`${s.name}:${kws.join(',')}`);return{ok:1}});
route('POST','/admin/bootstrap',c=>{const u=need(c),T=process.env.ADMIN_SETUP_TOKEN||'';if(!T)throw err(404,'غير متاح');if(get("SELECT 1 x FROM users WHERE role='admin'"))throw err(403,'تم إعداد المدير مسبقًا');
if(!ADMIN||u.email!==ADMIN)throw err(403,'هذا الحساب ليس حساب المالك');const t=String(c.b.token||'');if(t.length!==T.length||!crypto.timingSafeEqual(Buffer.from(t),Buffer.from(T)))throw err(403,'الرمز غير صحيح');
run("UPDATE users SET role='admin' WHERE id=?",u.id);audit(u.id,'bootstrap_admin',`user:${u.id}`);return{ok:1}});

const RESTORE_PREVIEW=DB_PATH+'.preview';
const restoreBackupDir=process.env.BACKUP_DIR||path.join(path.dirname(path.resolve(DB_PATH)),'backups');
const readSqliteFile=(file)=>{const d=new DBX(file);try{const t=new Set(d.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(x=>x.name));if(!t.has('users')||!t.has('agreements')||!t.has('skill_categories'))throw err(400,'الملف ليس نسخة صالحة من قاعدة المنصة');const c=n=>d.prepare('SELECT COUNT(*) n FROM '+n).get().n;return{users:c('users'),agreements:c('agreements')}}finally{d.close()}};
route('POST','/admin/restore/preview',c=>{const a=adm(c);const b64=String(c.b.data||'');if(!b64)throw err(400,'اختر ملف النسخة أولًا');const buf=Buffer.from(b64,'base64');if(buf.length<100||buf.subarray(0,15).toString('latin1')!=='SQLite format 3')throw err(400,'الملف ليس قاعدة بيانات SQLite');
fs.writeFileSync(RESTORE_PREVIEW,buf);try{const counts=readSqliteFile(RESTORE_PREVIEW);audit(a.id,'restore_preview',`${buf.length} bytes`);return{ok:1,counts}}catch(e){try{fs.unlinkSync(RESTORE_PREVIEW)}catch{}throw e}});
route('POST','/admin/restore/cancel',c=>{adm(c);try{fs.unlinkSync(RESTORE_PREVIEW)}catch{}try{fs.unlinkSync(RESTORE_PENDING)}catch{}return{ok:1}});
route('POST','/admin/restore/apply',c=>{const a=adm(c);if(String(c.b.confirm||'').trim()!=='استعادة')throw err(400,'اكتب كلمة «استعادة» للتأكيد');if(!fs.existsSync(RESTORE_PREVIEW))throw err(400,'لا توجد معاينة نشطة، اختر الملف وعاينه أولًا');
fs.mkdirSync(restoreBackupDir,{recursive:true,mode:0o700});const safety=path.join(restoreBackupDir,`pre-restore-${new Date().toISOString().replace(/[:.]/g,'-')}.db`);db.exec(`VACUUM INTO '${safety.replace(/'/g,"''")}'`);fs.chmodSync(safety,0o600);
fs.renameSync(RESTORE_PREVIEW,RESTORE_PENDING);audit(a.id,'restore_apply',path.basename(safety));
setTimeout(()=>process.exit(0),800);return{ok:1,restarting:true,safety:path.basename(safety)}});
route('GET','/admin/contact-messages',c=>{can(c,'support');return all('SELECT id,name,email,body,created_at FROM contact_messages ORDER BY id DESC LIMIT 100')});
route('POST','/admin/contact-messages/(\\d+)/delete',c=>{const a=can(c,'support');const m=get('SELECT id FROM contact_messages WHERE id=?',+c.p[0]);if(!m)throw err(404,'غير موجودة');run('DELETE FROM contact_messages WHERE id=?',m.id);audit(a.id,'contact_message_deleted',String(m.id));return{ok:1}});

route('GET','/admin/users',c=>{can(c,'support');const q=String(c.q.q||'').trim().slice(0,80);const like=q?`%${q.replace(/[%_\\]/g,m=>'\\'+m)}%`:'%';return all("SELECT id,name,email,role,account_type,active,flagged,created_at FROM users WHERE (name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\') ORDER BY id DESC LIMIT 200",like,like)});
route('GET','/admin/categories',c=>{adm(c);return all('SELECT id,name,sort FROM skill_categories ORDER BY sort').map(x=>({...x,words:all('SELECT word FROM section_keywords WHERE category_id=? ORDER BY word',x.id).map(r=>r.word)}))});
route('POST','/admin/sections/(\\d+)/keywords/remove',c=>{const a=adm(c),cat=get('SELECT id FROM skill_categories WHERE id=?',+c.p[0]);if(!cat)throw err(404,'القسم غير موجود');const w=normAr(String(c.b.word||''));if(!w)throw err(400,'الكلمة غير صالحة');run('DELETE FROM section_keywords WHERE category_id=? AND word=?',cat.id,w);audit(a.id,'keyword_removed',`${cat.id}:${w}`);return{ok:1}});


route('GET','/admin/points',c=>{can(c,'finance');const q=String(c.q.q||'').trim().slice(0,80);const like=q?`%${q.replace(/[%_\\]/g,m=>'\\'+m)}%`:'%';return all("SELECT u.id,u.name,u.email,COALESCE((SELECT SUM(delta) FROM points_ledger WHERE user_id=u.id),0) balance FROM users u WHERE (u.name LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\') ORDER BY balance DESC,u.id DESC LIMIT 100",like,like)});
route('POST','/admin/users/(\\d+)/points',c=>{const a=can(c,'finance'),uid=+c.p[0];const u=get('SELECT id FROM users WHERE id=?',uid);if(!u)throw err(404,'المستخدم غير موجود');
const d=Number(c.b.delta);if(!Number.isInteger(d)||d===0||Math.abs(d)>10000)throw err(400,'أدخل عددًا صحيحًا بين -10000 و 10000 (غير صفر)');
const why=str(c.b.reason,3,200,'السبب');const bal=get('SELECT COALESCE(SUM(delta),0) n FROM points_ledger WHERE user_id=?',uid).n;if(bal+d<0)throw err(400,'الرصيد لا يكفي للخصم');
run('INSERT INTO points_ledger(user_id,delta,reason,ref) VALUES(?,?,?,?)',uid,d,'إدارة: '+why,'admin:'+crypto.randomUUID());audit(a.id,'points_adjust',`${uid}:${d}`);return{ok:1,balance:bal+d}});
route('GET','/admin/growth',c=>{adm(c);return{users:all("SELECT date(created_at) d,COUNT(*) n FROM users WHERE created_at>=datetime('now','-30 days') GROUP BY d ORDER BY d")}});

route('GET','/admin/staff',c=>{adm(c);return all("SELECT id,name,email,perms FROM users WHERE role='staff' ORDER BY id")});
route('POST','/admin/staff',c=>{const a=adm(c),email=String(c.b.email||'').trim().toLowerCase();const t=email?get('SELECT id,role FROM users WHERE email=? AND active=1',email):null;if(!t)throw err(404,'لا يوجد حساب فعّال بهذا البريد');if(t.id===a.id)throw err(400,'لا يمكنك تغيير صلاحياتك');if(t.role==='admin')throw err(400,'هذا الحساب مدير بالفعل');
const allowed=['finance','support'];const perms=[...new Set((Array.isArray(c.b.perms)?c.b.perms:[]).filter(p=>allowed.includes(p)))];
run("UPDATE users SET role=?,perms=? WHERE id=?",perms.length?'staff':'user',perms.join(','),t.id);audit(a.id,'staff_perms',`${t.id}:${perms.join(',')||'none'}`);return{ok:1,perms}});

const wdSince=ts=>{if(!ts)return 0;let d=new Date(String(ts).replace(' ','T')+'Z'),n=0;const now=new Date();for(let x=new Date(d);x<now;x.setUTCDate(x.getUTCDate()+1)){const w=x.getUTCDay();if(w!==5&&w!==6)n++}return n};
route('GET','/admin/disputes',c=>{can(c,'support');const rows=all("SELECT g.id,g.amount,g.description,g.status,g.dispute_decision,g.dispute_note,g.dispute_by,g.dispute_review_by,g.dispute_final,g.disputed_at,g.dispute_decided_at,g.a_id,g.b_id FROM agreements g WHERE g.status='disputed' ORDER BY g.disputed_at");return rows.map(r=>{const open=!r.dispute_decision;const wd=open?wdSince(r.disputed_at):wdSince(r.dispute_decided_at);const limit=open?6:3;return{...r,wd_elapsed:wd,deadline_working_days:limit,overdue:wd>limit}})});
route('POST','/admin/disputes/(\\d+)/decide',c=>tx(()=>{const u=can(c,'support'),id=+c.p[0];const g=get('SELECT * FROM agreements WHERE id=?',id);if(!g||g.status!=='disputed')throw err(404,'النزاع غير موجود أو مغلق');if(g.a_id===u.id||g.b_id===u.id)throw err(403,'لا يفصل في النزاع أحد طرفيه');if(g.dispute_decision)throw err(400,'سبق اتخاذ قرار أولي');
const d=c.b.decision;if(!['completed','not_proven','partial'].includes(d))throw err(400,'قرار غير صالح');const note=str(c.b.note,3,300,'التعليل');
run('UPDATE agreements SET dispute_decision=?,dispute_note=?,dispute_by=?,dispute_decided_at=datetime(\'now\') WHERE id=?',d,note,u.id,id);audit(u.id,'dispute_decide',id+':'+d);return{ok:1}}));
route('POST','/admin/disputes/(\\d+)/review',c=>tx(()=>{const u=can(c,'support'),id=+c.p[0];const g=get('SELECT * FROM agreements WHERE id=?',id);if(!g||g.status!=='disputed'||!g.dispute_decision)throw err(404,'لا يوجد قرار أولي للمراجعة');if(g.dispute_by===u.id)throw err(403,'المراجعة من مسؤول آخر غير من اتخذ القرار الأول');if(g.a_id===u.id||g.b_id===u.id)throw err(403,'لا يراجع أحد طرفي الاتفاق');
const d=c.b.decision;if(!['completed','not_proven','partial'].includes(d))throw err(400,'قرار غير صالح');const final=d;
run('UPDATE agreements SET dispute_review_by=?,dispute_final=?,dispute_decision=?,status=? WHERE id=?',u.id,final==='completed'?1:0,final,final==='completed'?'completed':'closed_disputed',id);
if(final==='completed'){ensureCommission(id)}
if(final==='completed'){run("UPDATE agreement_commissions SET status='due' WHERE agreement_id=? AND status='on_hold' AND amount>0",id)}else{run("UPDATE agreement_commissions SET status='refund_due' WHERE agreement_id=? AND status='paid'",id);run("UPDATE agreement_commissions SET status='void' WHERE agreement_id=? AND status IN ('due','on_hold')",id)}
audit(u.id,'dispute_final',id+':'+final);return{ok:1,status:final==='completed'?'completed':'closed_disputed'}}));

route('GET','/admin/supply-report',c=>{adm(c);const thr=Number(SET().vat_threshold)||0;
const months=[];const now=new Date();for(let i=11;i>=0;i--){const d=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth()-i,1));months.push(d.toISOString().slice(0,7))}
const rows=months.map(m=>{
const comm=get("SELECT COALESCE(SUM(c.amount),0) s FROM agreement_commissions c JOIN agreements g ON g.id=c.agreement_id WHERE c.amount>0 AND strftime('%Y-%m',g.completed_at)=?",m).s;
const value=get("SELECT COALESCE(SUM(g.amount),0) s FROM agreements g WHERE g.status='completed' AND strftime('%Y-%m',g.completed_at)=?",m).s;
const freeCount=get("SELECT COUNT(*) n FROM agreement_commissions c JOIN agreements g ON g.id=c.agreement_id WHERE c.amount=0 AND strftime('%Y-%m',g.completed_at)=?",m).n;
const cancelled=get("SELECT COUNT(*) n FROM agreements WHERE status='cancelled' AND strftime('%Y-%m',updated_at)=?",m).n;
const disputes=get("SELECT COUNT(*) n FROM agreements WHERE disputed_at IS NOT NULL AND strftime('%Y-%m',disputed_at)=?",m).n;
return{month:m,platform_commission:Math.round(comm*100)/100,task_value:value,free_month_completions:freeCount,cancelled,disputes}});
const total=rows.reduce((s,r)=>s+r.task_value,0);const last3=rows.slice(-3).reduce((s,r)=>s+r.task_value,0)/3;const projected=Math.round(last3*12);
const status=thr<=0?'not_set':total>=thr?'exceeded':(total>=thr*0.8?'near':'below');
const expectedStatus=thr<=0?'not_set':(total+projected>=thr||projected>=thr?'expected_to_exceed':'below');
return{threshold:thr,trailing_12_months_value:total,projected_next_12_months_value:projected,status,expected_status:expectedStatus,warn_at:Math.round(thr*0.8),rows,note:'تقدير داخلي للمتابعة. الحد الإلزامي يحدده المحاسب، وطلب التسجيل يقدَّم خلال 30 يومًا من نهاية الشهر المعني عند التجاوز أو توقعه.'}});
route('POST','/admin/supply-threshold',c=>{const u=adm(c);const v=Number(c.b.value);if(!Number.isFinite(v)||v<0)throw err(400,'قيمة غير صالحة');run("INSERT INTO settings(key,value) VALUES('vat_threshold',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",String(v));audit(u.id,'vat_threshold',String(v));return{ok:1}});


route('GET','/admin/verifications',c=>{adm(c);return{vat:all("SELECT id,name,email,helper_type,vat_number FROM users WHERE account_type='helper' AND helper_type IN ('establishment','company') AND vat_status='registered' AND vat_verified!=1"),type_requests:all("SELECT id,name,email,helper_type,helper_type_request FROM users WHERE helper_type_request IS NOT NULL")}});
route('POST','/admin/vat/(\\d+)/verify',c=>{const a=adm(c),id=+c.p[0];const u=get('SELECT id FROM users WHERE id=?',id);if(!u)throw err(404,'المستخدم غير موجود');const ok=c.b.decision==='approve';
if(ok)run('UPDATE users SET vat_verified=1 WHERE id=?',id);else run("UPDATE users SET vat_verified=2 WHERE id=?",id);
run('INSERT INTO direct_messages(from_id,to_id,body) VALUES(?,?,?)',a.id,id,ok?'تم التحقق من رقمك الضريبي، ويمكنك الآن استقبال الطلبات.':'لم يتم التحقق من الرقم الضريبي، يرجى مراجعة البيانات وإعادة الإرسال.');audit(a.id,'vat_verify',id+':'+(ok?'approve':'reject'));return{ok:1}});
route('POST','/admin/helper-type/(\\d+)/decide',c=>{const a=adm(c),id=+c.p[0];const u=get('SELECT id,helper_type_request FROM users WHERE id=?',id);if(!u||!u.helper_type_request)throw err(404,'لا يوجد طلب تغيير');
if(c.b.decision==='approve'){run("UPDATE users SET helper_type=?,helper_type_request=NULL,vat_verified=0 WHERE id=?",u.helper_type_request,id)}else{run('UPDATE users SET helper_type_request=NULL WHERE id=?',id)}
run('INSERT INTO direct_messages(from_id,to_id,body) VALUES(?,?,?)',a.id,id,c.b.decision==='approve'?'تمت الموافقة على تغيير نوع حسابك.':'لم تتم الموافقة على تغيير نوع حسابك.');audit(a.id,'helper_type_decide',id+':'+c.b.decision);return{ok:1}});

route('GET','/admin/invoices',c=>{adm(c);return all('SELECT id,kind,seq,ref,buyer_name,buyer_vat,subtotal,vat_rate,vat_amount,total,issued_at,qr,status FROM invoices ORDER BY id DESC LIMIT 100')});
route('POST','/admin/invoicing',c=>{const a=adm(c);const reg=!!c.b.platform_vat_registered;const vat=String(c.b.platform_vat_number||'').replace(/\s/g,'');
if(reg&&!/^3\d{14}$/.test(vat))throw err(400,'الرقم الضريبي للمنصة يتكون من 15 رقمًا ويبدأ بـ 3');
run("INSERT INTO settings(key,value) VALUES('platform_vat_registered',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",reg?'1':'0');
run("INSERT INTO settings(key,value) VALUES('platform_vat_number',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",reg?vat:'');
audit(a.id,'invoicing_config',reg?'registered':'not_registered');return{ok:1}});
route('POST','/admin/agreement-commissions/(\\d+)/refunded',c=>{can(c,'finance');const row=get("SELECT id FROM agreement_commissions WHERE id=? AND status='refund_due'",c.p[0]);if(!row)throw err(400,'هذه العمولة لا تحتاج استردادًا');run("UPDATE agreement_commissions SET status='refunded' WHERE id=?",row.id);audit(c.u.id,'agreement_commission_refunded',String(row.id));return{ok:1}});

// تحليلات البحث وتحليلات الأقسام (الطلبات المنشورة أُلغيت، فيبقى البحث الفاشل والعرض)
route('GET','/admin/insights',c=>{adm(c);const days=[7,30,0].includes(+c.q.days)?+c.q.days:30,since=days?new Date(Date.now()-days*864e5).toISOString().slice(0,19).replace('T',' '):'1970-01-01 00:00:00';
const supply=new Map(all("SELECT us.category_id,COUNT(*) n FROM user_sections us JOIN users u ON u.id=us.user_id WHERE u.active=1 AND u.account_type='helper' GROUP BY us.category_id").map(x=>[x.category_id,x.n]));
const demand=[];const gap=demand.map(d=>({id:d.id,name:d.name,cat:d.cat,n:d.n,helpers:supply.get(d.id)||0}));
const failed=all(`SELECT text,COUNT(*) n,MAX(at) last FROM failed_searches WHERE at>=? GROUP BY text ORDER BY n DESC,last DESC LIMIT 20`,since);
return{days,total:0,demand,gap,failed}});

// بلاغات الرسائل المباشرة: عرض المحادثة بين الطرفين
route('GET','/admin/reports/(\\d+)/conversation',c=>{const a=can(c,'support'),r=get('SELECT * FROM reports WHERE id=?',+c.p[0]);if(!r)throw err(404,'البلاغ غير موجود');
const m=r.type==='message'?get('SELECT from_id,to_id FROM direct_messages WHERE id=?',r.target_id):null;if(!m)throw err(400,'هذا البلاغ لا يتعلق بمحادثة');
const rows=all('SELECT m.id,m.body,m.from_id,m.created_at,u.name sender FROM direct_messages m JOIN users u ON u.id=m.from_id WHERE (m.from_id=? AND m.to_id=?) OR (m.from_id=? AND m.to_id=?) ORDER BY m.id LIMIT 300',m.from_id,m.to_id,m.to_id,m.from_id);
audit(a.id,'chat_view','report:'+r.id);return{messages:rows}});

route('GET','/admin/ratings',c=>{can(c,'support');return all('SELECT r.id,r.stars,r.comment,r.hidden,r.agreement_id,u.name rater,t.name rated FROM ratings r JOIN users u ON u.id=r.rater_id JOIN users t ON t.id=r.ratee_id ORDER BY r.id DESC LIMIT 200')});
route('POST','/admin/ratings/(\\d+)/hidden',c=>{const a=can(c,'support'),x=get('SELECT id FROM ratings WHERE id=?',+c.p[0]);if(!x)throw err(404,'التقييم غير موجود');const h=c.b.hidden?1:0;run('UPDATE ratings SET hidden=? WHERE id=?',h,x.id);audit(a.id,h?'rating_hidden':'rating_shown',String(x.id));return{ok:1}});
